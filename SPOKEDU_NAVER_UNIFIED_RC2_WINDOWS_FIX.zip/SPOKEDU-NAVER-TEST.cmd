@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PS_EXE=%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe"
if not exist "%PS_EXE%" (
  echo [SPOKEDU] ERROR: Windows PowerShell not found.
  pause
  exit /b 20
)
if not exist "%~dp0SPOKEDU-NAVER.ps1" (
  echo [SPOKEDU] ERROR: SPOKEDU-NAVER.ps1 missing. Extract ZIP to repo root.
  pause
  exit /b 21
)
"%PS_EXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SPOKEDU-NAVER.ps1" -Demo -Smoke
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo [SPOKEDU] FAILED: see above and report. Original Chrome tabs are not closed.
if "%RESULT%"=="0" echo [SPOKEDU] COMPLETED: check report for exact verification scope.
pause
exit /b %RESULT%
