﻿# SPOKEDU unified Naver preview launcher. Never kills Chrome, modifies an existing tab, saves or publishes.
[CmdletBinding()]
param(
  [string]$ArticleDir = "",
  [switch]$Demo,
  [switch]$Smoke,
  [switch]$Check,
  [switch]$NewPreview
)
$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$dir = Join-Path $root 'scripts\naver-blog-p0\rich-paste\spokedu-unified'
$reportDir = Join-Path $root 'reports\naver-new\rich-paste\spokedu-unified'
$env:NAVER_CDP_URL = 'http://127.0.0.1:9222'
try {
  if (!(Test-Path $dir)) { throw "UNIFIED_ENGINE_NOT_FOUND: $dir" }
  $node = Get-Command node -ErrorAction SilentlyContinue
  if (!$node) { throw 'NODE_NOT_FOUND: 기존 Node.js 설치가 필요합니다.' }
  if ($Demo -and $ArticleDir) { throw 'ARTICLE_SELECTION_CONFLICT: Demo와 ArticleDir 동시 사용 금지' }
  $mode = if ($Check) { '--check' } elseif ($Smoke) { '--smoke' } else { '--preview' }
  $articleArgs = @()
  if ($Demo) {
    $articleArgs = @('--example')
    Write-Host '입력 대상: 청담 수업 샘플 (로컬 Gemma 원고 아님)' -ForegroundColor Yellow
  } elseif ($ArticleDir) {
    if (!(Test-Path (Join-Path $ArticleDir 'manifest.json'))) { throw 'MANIFEST_NOT_FOUND: 기사 폴더에 manifest.json 필요' }
    $articleArgs = @('--article', (Resolve-Path $ArticleDir).Path)
    Write-Host "입력 대상: $ArticleDir"
  } else {
    # The local writer is the source of truth. No silent fallback to a ChatGPT-authored example.
    $local = Join-Path $env:USERPROFILE 'SPOKEDU-LLM\04_학습결과\SPOKEDU_AUTOPILOT\articles'
    if (!(Test-Path $local)) { throw "LOCAL_WRITER_NOT_FOUND: $local (샘플 시험은 -Demo)" }
    $ready = @(Get-ChildItem -LiteralPath $local -Directory -ErrorAction SilentlyContinue | ForEach-Object {
       $path = Join-Path $_.FullName 'manifest.json'
       $source = Join-Path $_.FullName 'ARTICLE_FOR_NAVER.md'
       if ((Test-Path $path) -and (Test-Path $source)) {
         try {
           $m = Get-Content -LiteralPath $path -Raw -Encoding UTF8 | ConvertFrom-Json
           if (($m.factualReviewApproved -eq $true) -and ($m.localLlmSourceUsed -eq $true) -and
               ($m.publicationAllowed -eq $false) -and ($m.draftSaveAllowed -eq $false) -and
               $m.photos.Count -gt 0) { Get-Item $_.FullName }
         } catch {}
       }
    } | Sort-Object LastWriteTime -Descending)
    if (!$ready.Count) {
       throw 'LOCAL_CONTENT_NOT_READY: 기존 로컬 Gemma 산출물에 승인된 매니페스트·사진이 없어 중단했습니다. 임의 원고로 대체하지 않습니다. 엔진 시험만 하려면 SPOKEDU-NAVER.cmd -Demo -Smoke'
    }
    $articleArgs = @('--article', $ready[0].FullName)
    Write-Host "로컬 승인 원고: $($ready[0].FullName)" -ForegroundColor Cyan
  }
  Set-Location $dir
  Write-Host '[QA] 통합 엔진 회귀 테스트'
  & node --test | Out-File -FilePath (Join-Path $dir 'qa-latest.log') -Encoding utf8
  if ($LASTEXITCODE -ne 0) { throw 'QA_TEST_FAILED: spokedu-unified\qa-latest.log 확인' }
  Write-Host '오프라인 회귀 테스트 PASS' -ForegroundColor Green
  Write-Host '[G0] 원본·이미지 무결성 검사'
  & node .\run.mjs --check @articleArgs
  if ($LASTEXITCODE -ne 0) { throw 'SOURCE_CHECK_FAILED: 보고서 확인' }
  if ($Check) { Write-Host 'G0 PASS. 네이버 접속·사진 업로드 없음.' -ForegroundColor Green; exit 0 }
  Write-Host '[G1] 기존 Chrome CDP·네이버 세션 연결 검사'
  function Test-Cdp {
    try {
      $r = Invoke-RestMethod "$env:NAVER_CDP_URL/json/version" -TimeoutSec 3
      return [bool]($r.Browser -and $r.webSocketDebuggerUrl)
    } catch { return $false }
  }
  if (!(Test-Cdp)) {
    $profile = Join-Path $env:LOCALAPPDATA 'SPOKEDU-Naver-CDP'
    $inUse = @(Get-CimInstance Win32_Process -Filter "name='chrome.exe'" |
      Where-Object { $_.CommandLine -and $_.CommandLine.Contains($profile) })
    if ($inUse.Count -gt 0) { throw 'CDP_PROFILE_ALREADY_RUNNING_WITHOUT_PORT: 기존 Chrome/미저장 탭 보호를 위해 중단합니다. 프로세스를 종료하지 않습니다.' }
    if (!(Test-Path $profile)) { throw "CDP_PROFILE_MISSING: $profile (새 프로필·재로그인 자동 생성 금지)" }
    $chrome = @(
      "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
      "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe",
      "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe"
    ) | Where-Object { Test-Path $_ } | Select-Object -First 1
    if (!$chrome) { throw 'CHROME_NOT_FOUND' }
    Start-Process -FilePath $chrome -ArgumentList @(
      '--remote-debugging-port=9222', '--remote-debugging-address=127.0.0.1',
      "--user-data-dir=`"$profile`"", 'about:blank'
    )
    $ok = $false
    for ($i=0; $i -lt 12; $i++) { Start-Sleep -Seconds 1; if(Test-Cdp){$ok=$true;break} }
    if (!$ok) { throw 'CDP_START_FAILED: 프로필 보존. 자동 재시도 안 함.' }
  }
  $options = @($mode)+$articleArgs
  if ($NewPreview) { $options += '--new-preview' }
  Write-Host '[G1-G3] 새 작성 탭 진입 → 에디터 검증 → 미리보기 입력'
  & node .\run.mjs @options
  if ($LASTEXITCODE -ne 0) {
    $latest = Get-ChildItem -LiteralPath $reportDir -Filter 'photo-sequential-*.json' -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTime -Descending | Select-Object -First 1
    if ($latest) {
      $r = Get-Content -LiteralPath $latest.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
      Write-Host "중단 단계: $($r.failedStage)" -ForegroundColor Red
      Write-Host "실제 원인: $($r.code) | $($r.error)" -ForegroundColor Red
      Write-Host "진단: $($latest.FullName)"
    }
    throw 'RUN_STOPPED: 실패 원인에 따라 안전하게 중단했습니다. 자동 재실행하지 않습니다.'
  }
  if ($Smoke) { Write-Host 'G1 편집기 진입 확인 완료. 사진·본문 업로드는 하지 않았습니다.' -ForegroundColor Green }
  else { Write-Host 'DOM 검증 단계 완료. 실제 화면·링크·아동 사진 공개 승인은 별도로 필요합니다.' -ForegroundColor Yellow }
  Write-Host "보고서 폴더: $reportDir"
  exit 0
} catch {
  Write-Host "[SPOKEDU] 실패: $($_.Exception.Message)" -ForegroundColor Red
  exit 2
}
