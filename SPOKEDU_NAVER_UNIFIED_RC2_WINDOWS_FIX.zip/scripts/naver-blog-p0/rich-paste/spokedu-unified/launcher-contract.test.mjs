import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = resolve(dirname(fileURLToPath(import.meta.url)), '../../../..');
const readRoot = file => readFile(resolve(root, file));
function isStrictCrLf(bytes) {
  const b = bytes.toString('latin1');
  return b.includes('\r\n') && !b.replaceAll('\r\n','').includes('\n') &&
    !b.replaceAll('\r\n','').includes('\r');
}
for (const [name, flags] of [['SPOKEDU-NAVER-TEST.cmd','-Demo -Smoke'],['SPOKEDU-NAVER.cmd','%*']]) {
  test(`${name}: ASCII-only, CRLF-only, no UTF-8 BOM`, async () => {
    const b = await readRoot(name);
    assert.ok(isStrictCrLf(b));
    assert.ok([...b].every(x=>x<128));
    assert.equal(b[0], 64);
  });
  test(`${name}: calls pinned native Windows PowerShell with expected flags`, async () => {
    const s = (await readRoot(name)).toString('ascii');
    assert.match(s, /%SystemRoot%\\System32\\WindowsPowerShell\\v1\.0\\powershell\.exe/i);
    assert.match(s, /"%PS_EXE%" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0SPOKEDU-NAVER\.ps1"/);
    assert.ok(s.includes(' '+flags+'\r\n'));
  });
}
test('Windows PowerShell 5.1 loader: UTF-8 BOM and CRLF', async () => {
  const b=await readRoot('SPOKEDU-NAVER.ps1');
  assert.deepEqual([...b.slice(0,3)],[0xef,0xbb,0xbf]);
  assert.ok(isStrictCrLf(b.subarray(3)));
  const s = b.toString('utf8');
  assert.ok(s.includes('SPOKEDU_AUTOPILOT'));
  assert.ok(s.includes('04_학습결과'));
});
test('launchers do not kill browsers, publish, or write posts', async () => {
  const joined = (await Promise.all(['SPOKEDU-NAVER.cmd','SPOKEDU-NAVER-TEST.cmd'].map(async f=>(await readRoot(f)).toString('ascii')))).join('\n');
  assert.doesNotMatch(joined, /taskkill|Stop-Process|--publish|--save-draft/i);
});
