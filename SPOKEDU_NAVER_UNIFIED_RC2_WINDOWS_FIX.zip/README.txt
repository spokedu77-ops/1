﻿SPOKEDU NAVER UNIFIED RC2 - LAUNCHER REPAIR ONLY

CAUSE OF THE RC1 START FAILURE
- .cmd files shipped with Unix LF endings (Windows CMD requires CRLF for reliable handling).
- .cmd files contained UTF-8 Korean text directly.
- .ps1 lacked UTF-8 BOM, making Korean folder names unsafe on Windows PowerShell 5.1.
- The earlier 25 unit tests did not inspect launch files.

FIXED IN RC2
- Both .cmd wrappers: ASCII + CRLF and absolute Windows PowerShell path.
- SPOKEDU-NAVER.ps1: UTF-8 BOM + CRLF.
- launcher-contract.test.mjs: enforces exact file byte invariants and arguments.
- All original engine/content files from RC1 preserved byte-for-byte.

INSTALL
1. Extract this ZIP directly to C:\Users\joker\Documents\GitHub\1 and allow replacement.
2. Double-click C:\Users\joker\Documents\GitHub\1\SPOKEDU-NAVER-TEST.cmd.
3. The TEST command checks the sample article and editor entry only. It does not paste/upload photos or publish anything.
4. Keep original Chrome windows and any unsaved tabs as they are.
5. If the test fails, report the printed code and report path; no repeated uploads.

SAFETY
- This package has NOT been tested in a real Windows command interpreter or Naver session by the assistant.
- This package preserves original operational runner from RC1; this specific update repairs Windows command entry only.
- Success of offline tests DOES NOT mean real Naver editor readiness or visual quality PASS.
