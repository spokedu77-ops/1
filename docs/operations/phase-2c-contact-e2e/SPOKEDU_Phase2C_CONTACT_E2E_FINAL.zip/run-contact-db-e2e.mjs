#!/usr/bin/env node
/**
 * Phase 2-C — real DB E2E (local/staging Supabase via service role + HTTP API).
 * Production DB writes forbidden — uses synthetic markers only.
 */
import nextEnv from '@next/env';
import { createClient } from '@supabase/supabase-js';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const docsDir = path.dirname(fileURLToPath(import.meta.url));
const repoRoot = path.resolve(docsDir, '../../..');
const { loadEnvConfig } = nextEnv;
loadEnvConfig(repoRoot);

const port = process.env.CONTACT_E2E_PORT ?? '3022';
const base = `http://127.0.0.1:${port}`;
const runId = `PHASE2C-${Date.now().toString(36).toUpperCase()}`;
const marker = `[${runId}]`;

const evidence = {
  runId,
  marker,
  port,
  base,
  BUILD_ID: null,
  schema: {},
  cases: [],
  admin: {},
  cleanup: [],
  overall: 'FAIL',
};

function fail(msg) {
  evidence.fatal = msg;
  throw new Error(msg);
}

async function waitServer() {
  for (let i = 0; i < 120; i++) {
    try {
      const r = await fetch(`${base}/contact`, { method: 'HEAD' });
      if (r.status < 500) return;
    } catch {
      /* */
    }
    await new Promise((r) => setTimeout(r, 350));
  }
  fail('server timeout');
}

function supabaseAdmin() {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  if (!url || !key) fail('Supabase env missing — ENVIRONMENT_BLOCKED for DB E2E');
  return createClient(url, key, { auth: { persistSession: false } });
}

async function postJson(pathname, body) {
  const res = await fetch(`${base}${pathname}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', accept: 'application/json' },
    body: JSON.stringify(body),
  });
  const json = await res.json().catch(() => null);
  return { status: res.status, json };
}

async function probeSchema(sb) {
  const tables = ['consultations', 'dispatch_leads'];
  const out = {};
  for (const table of tables) {
    const probe = await sb.from(table).select('*').limit(1);
    out[table] = {
      reachable: !probe.error || probe.error.code !== '42P01',
      error: probe.error?.message ?? null,
      code: probe.error?.code ?? null,
    };
  }
  const consultCols = ['lead_route', 'lead_context', 'curriculum_mode', 'source_lead_id'];
  const colProbe = await sb.from('consultations').select(consultCols.join(',')).limit(1);
  out.consultations_structured = {
    ok: !colProbe.error,
    error: colProbe.error?.message ?? null,
    code: colProbe.error?.code ?? null,
  };
  const dispatchCols = ['mirror_consult_id', 'mirror_status'];
  const dProbe = await sb.from('dispatch_leads').select(dispatchCols.join(',')).limit(1);
  out.dispatch_leads_structured = {
    ok: !dProbe.error,
    error: dProbe.error?.message ?? null,
    code: dProbe.error?.code ?? null,
  };
  return out;
}

async function cleanupRows(sb, ids) {
  for (const id of ids.consultIds) {
    if (!id) continue;
    const d = await sb.from('consultations').delete().eq('id', id);
    evidence.cleanup.push({ table: 'consultations', id, error: d.error?.message ?? null });
  }
  for (const id of ids.dispatchIds) {
    if (!id) continue;
    const d = await sb.from('dispatch_leads').delete().eq('id', id);
    evidence.cleanup.push({ table: 'dispatch_leads', id, error: d.error?.message ?? null });
  }
}

function record(id, status, detail) {
  evidence.cases.push({ id, status, ...detail });
}

let srv;
try {
  await mkdir(docsDir, { recursive: true });
  const sb = supabaseAdmin();
  evidence.schema = await probeSchema(sb);
  if (!evidence.schema.consultations?.reachable) {
    fail('consultations table unreachable');
  }

  if (process.env.CONTACT_E2E_NO_SPAWN !== '1') {
    srv = spawn('npm run start', {
      cwd: repoRoot,
      shell: true,
      stdio: 'pipe',
      env: { ...process.env, PORT: port },
    });
  }
  await waitServer();

  try {
    evidence.BUILD_ID = (await readFile(path.join(repoRoot, '.next', 'BUILD_ID'), 'utf8')).trim();
  } catch {
    evidence.BUILD_ID = null;
  }

  const created = { consultIds: [], dispatchIds: [] };
  const phoneSuffix = String(Date.now()).slice(-4);
  const synthPhone = `0109999${phoneSuffix}`;

  // E06 / validation
  {
    const r = await postJson('/api/private/leads', { type: 'private', name: '', phone: '', content: '' });
    record('E06', r.status === 400 && r.json?.ok === false ? 'PASS' : 'FAIL', {
      dbVerified: false,
      mock: false,
      http: r.status,
    });
  }

  // C01 E01 private
  {
    const content = `${marker} C01 private E2E\n이름: 합성테스트\n연락처: ${synthPhone}`;
    const body = {
      type: 'private',
      name: `합성_${runId}`,
      phone: synthPhone,
      email: 'phase2c.synthetic@spokedu.test',
      content,
      preferred_format: 'undecided',
      cta_intent_id: 'private_fit_consult',
      acquisition: { entrySurface: 'direct' },
    };
    const r = await postJson('/api/private/leads', body);
    const leadId = r.json?.leadId;
    let dbOk = false;
    if (r.status === 200 && r.json?.ok && leadId) {
      const row = await sb.from('consultations').select('id, consult_type, phone, content, parent_name').eq('id', leadId).maybeSingle();
      dbOk =
        !!row.data &&
        row.data.consult_type === 'tutoring' &&
        row.data.phone === synthPhone &&
        String(row.data.content).includes(marker);
      if (dbOk) created.consultIds.push(leadId);
    }
    record('C01/E01', dbOk ? 'PASS' : 'FAIL', {
      requestId: runId,
      leadId,
      dbVerified: dbOk,
      emailSent: r.json?.emailSent ?? null,
      mock: false,
      http: r.status,
    });

    const dup = await postJson('/api/private/leads', body);
    record(
      'E11-private-dup',
      dup.json?.duplicate === true && dup.json?.leadId === leadId ? 'PASS' : 'FAIL',
      { dbVerified: false, mock: false, http: dup.status },
    );
  }

  // C02 dispatch
  {
    const org = `합성기관_${runId}`;
    const inquiry = `${marker} C02 dispatch E2E`;
    const body = {
      type: 'dispatch',
      organization: org,
      manager: `담당_${runId}`,
      phone: synthPhone,
      email: 'phase2c.synthetic@spokedu.test',
      location: '서울',
      headcount: '30',
      specialNeeds: inquiry,
      inquiry,
      programs: ['정규수업'],
      targetAge: ['초등'],
      source: 'phase2c-e2e',
      cta_intent_id: 'dispatch_proposal',
      acquisition: { entrySurface: 'direct' },
    };
    const r = await postJson('/api/dispatch/leads', body);
    const consultId = r.json?.consultId ?? r.json?.leadId;
    const detailId = r.json?.detailId;
    let dbOk = false;
    let linkOk = false;
    if (r.status === 200 && r.json?.ok && consultId) {
      const c = await sb
        .from('consultations')
        .select('id, consult_type, source_lead_id, content, parent_name')
        .eq('id', consultId)
        .maybeSingle();
      dbOk =
        !!c.data &&
        c.data.consult_type === 'center' &&
        String(c.data.content).includes(marker) &&
        String(c.data.parent_name).includes(org);
      if (detailId) {
        const d = await sb.from('dispatch_leads').select('id, mirror_consult_id, organization_name').eq('id', detailId).maybeSingle();
        linkOk = !!d.data && d.data.organization_name === org;
        created.dispatchIds.push(detailId);
      }
      linkOk = linkOk || r.json?.detailStatus === 'detail_failed';
      if (dbOk) created.consultIds.push(consultId);
    }
    record('C02/E02', dbOk ? 'PASS' : 'FAIL', {
      consultId,
      detailId,
      detailStatus: r.json?.detailStatus,
      dbVerified: dbOk,
      detailDbVerified: linkOk,
      mock: false,
    });
  }

  // C03 spomove via dispatch API
  {
    const org = `SPOMOVE_${runId}`;
    const inquiry = `${marker} C03 SPOMOVE E2E`;
    const body = {
      type: 'dispatch',
      organization: org,
      manager: `담당_${runId}`,
      phone: `0108888${phoneSuffix}`,
      email: 'phase2c.spomove@spokedu.test',
      location: '경기',
      headcount: '25',
      specialNeeds: inquiry,
      inquiry,
      programs: ['SPOMOVE'],
      targetAge: ['초등'],
      source: 'spokedu-contact-spomove',
      cta_intent_id: 'dispatch_proposal',
      acquisition: { entrySurface: 'direct' },
    };
    const r = await postJson('/api/dispatch/leads', body);
    const consultId = r.json?.consultId;
    let dbOk = false;
    if (consultId) {
      const c = await sb.from('consultations').select('id, content').eq('id', consultId).maybeSingle();
      dbOk = !!c.data && String(c.data.content).includes('SPOMOVE') && String(c.data.content).includes(marker);
      if (dbOk) created.consultIds.push(consultId);
      if (r.json?.detailId) created.dispatchIds.push(r.json.detailId);
    }
    record('C03/E03', dbOk ? 'PASS' : 'FAIL', { consultId, dbVerified: dbOk, mock: false });
  }

  // C04 curriculum master
  {
    const extra = `${marker} C04 curriculum E2E`;
    const body = {
      type: 'curriculum',
      lead_mode: 'master',
      name_or_org: `구독_${runId}`,
      phone: `0107777${phoneSuffix}`,
      email: 'phase2c.curriculum@spokedu.test',
      content_type: '구독시스템',
      target_age: '초등',
      purpose: '기관 도입',
      teacher_training: '상담 후 결정',
      partnership_type: '구독·교육',
      extra,
      cta_intent_id: 'master_org_inquiry',
      acquisition: { entrySurface: 'direct' },
    };
    const r = await postJson('/api/curriculum/leads', body);
    const leadId = r.json?.leadId;
    let dbOk = false;
    if (leadId) {
      const c = await sb
        .from('consultations')
        .select('id, content, curriculum_mode, lead_route')
        .eq('id', leadId)
        .maybeSingle();
      dbOk =
        !!c.data &&
        String(c.data.content).includes(marker) &&
        (c.data.curriculum_mode === 'master' || String(c.data.content).includes('lead_mode: master'));
      if (dbOk) created.consultIds.push(leadId);
    }
    const dup = await postJson('/api/curriculum/leads', body);
    record('C04/E04', dbOk ? 'PASS' : 'FAIL', {
      leadId,
      lead_mode: r.json?.lead_mode,
      dbVerified: dbOk,
      mock: false,
    });
    record(
      'E11-curriculum-dup',
      dup.json?.duplicate === true && dup.json?.leadId === leadId ? 'PASS' : 'FAIL',
      { dbVerified: false, mock: false },
    );
  }

  // C05 license
  {
    const extra = `${marker} C05 license E2E`;
    const body = {
      type: 'curriculum',
      lead_mode: 'license',
      name_or_org: `협업_${runId}`,
      phone: `0106666${phoneSuffix}`,
      content_type: '라이선스',
      target_age: '',
      purpose: '협업 검토',
      teacher_training: '상담 후 결정',
      partnership_type: '협업 검토',
      extra,
      cta_intent_id: 'license_consult',
      acquisition: { entrySurface: 'direct' },
    };
    const r = await postJson('/api/curriculum/leads', body);
    const leadId = r.json?.leadId;
    let dbOk = false;
    if (leadId) {
      const c = await sb.from('consultations').select('id, content, curriculum_mode').eq('id', leadId).maybeSingle();
      dbOk =
        !!c.data &&
        String(c.data.content).includes(marker) &&
        (c.data.curriculum_mode === 'license' || String(c.data.content).includes('lead_mode: license'));
      if (dbOk) created.consultIds.push(leadId);
    }
    record('C05/E05', dbOk ? 'PASS' : 'FAIL', { leadId, dbVerified: dbOk, mock: false });
  }

  // E07 invalid email dispatch
  {
    const r = await postJson('/api/dispatch/leads', {
      type: 'dispatch',
      organization: 'x',
      manager: 'y',
      phone: '',
      email: 'not-an-email',
      inquiry: 'z',
    });
    record('E07', r.status === 400 ? 'PASS' : 'FAIL', { dbVerified: false, http: r.status });
  }

  // E14 admin without session
  {
    const r = await fetch(`${base}/api/admin/consult?limit=5`);
    evidence.admin.unauthenticatedStatus = r.status;
    record('E14', r.status === 401 ? 'PASS' : 'FAIL', { dbVerified: false, mock: false, http: r.status });
  }

  // E15 — inbox query parity (same table/order as admin API; UI session not used)
  {
    const { data: list } = await sb
      .from('consultations')
      .select('id, parent_name, created_at, consult_type, status')
      .order('created_at', { ascending: false })
      .limit(50);
    const visible = (list ?? []).some((row) => created.consultIds.includes(row.id));
    evidence.admin.inboxParity = { visible, sampleIds: created.consultIds.slice(0, 3) };
    record('E15', visible ? 'PARTIAL' : 'FAIL', {
      dbVerified: true,
      adminUiVerified: false,
      note: 'Service-role inbox parity only; authenticated /admin/consult UI not exercised (no QA admin session in env).',
    });
  }

  // E10 notification — private response reports emailSent
  {
    const hasResend = Boolean(process.env.RESEND_API_KEY?.trim() && process.env.PRIVATE_LEADS_NOTIFY_EMAIL?.trim());
    evidence.notification = { resendConfigured: hasResend, verdict: hasResend ? 'NOT_VERIFIED' : 'NOT_CONFIGURED' };
    record('E10', hasResend ? 'NOT_VERIFIED' : 'NOT_VERIFIED', {
      note: 'No live email send in test; DB path independent of emailSent flag.',
      dbVerified: false,
    });
  }

  record('E08', 'NOT_VERIFIED', {
    note: 'Simulated DB outage not injected (would require unsafe env tampering). Client maps ok:false to failure message via inquiry-submit.test.',
    mock: true,
  });
  record('E09', 'NOT_VERIFIED', {
    note: 'detail_failed path exists in dispatch/leads; not forced in live DB.',
    mock: false,
  });

  await cleanupRows(sb, created);

  const hardFail = evidence.cases.some((c) =>
    ['C01/E01', 'C02/E02', 'C03/E03', 'C04/E04', 'C05/E05', 'E06', 'E14'].includes(c.id) && c.status === 'FAIL',
  );
  evidence.overall = hardFail ? 'FAIL' : 'PASS_WITH_GAPS';
  if (evidence.cases.some((c) => c.status === 'FAIL' && !c.id.startsWith('E'))) evidence.overall = 'FAIL';

  await writeFile(path.join(docsDir, 'DB_E2E_EVIDENCE.json'), JSON.stringify(evidence, null, 2));
  console.log(JSON.stringify({ overall: evidence.overall, runId, cases: evidence.cases.length }, null, 2));
  if (evidence.overall === 'FAIL') process.exit(1);
} catch (e) {
  evidence.overall = evidence.fatal?.includes('ENVIRONMENT') ? 'ENVIRONMENT_BLOCKED' : 'FAIL';
  evidence.error = String(e.message ?? e);
  await writeFile(path.join(docsDir, 'DB_E2E_EVIDENCE.json'), JSON.stringify(evidence, null, 2)).catch(() => {});
  console.error(e);
  process.exit(1);
} finally {
  if (srv) srv.kill('SIGTERM');
}
