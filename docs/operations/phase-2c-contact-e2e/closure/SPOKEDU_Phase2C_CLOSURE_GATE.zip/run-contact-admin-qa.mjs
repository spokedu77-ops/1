#!/usr/bin/env node
import nextEnv from '@next/env';
import { chromium } from 'playwright';
import { createClient } from '@supabase/supabase-js';
import { mkdir, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { spawn } from 'node:child_process';

const closureDir = path.dirname(fileURLToPath(import.meta.url));
const capDir = path.join(closureDir, 'captures');
const repoRoot = path.resolve(closureDir, '../../../..');
nextEnv.loadEnvConfig(repoRoot);

const port = process.env.CONTACT_QA_PORT ?? '3027';
const base = `http://127.0.0.1:${port}`;

const evidence = { port, BUILD_ID: null, E15: 'BLOCKED', checks: [], overall: 'BLOCKED' };

async function waitServer() {
  for (let i = 0; i < 120; i++) {
    try {
      if ((await fetch(`${base}/login`)).status < 500) return;
    } catch {
      /* */
    }
    await new Promise((r) => setTimeout(r, 350));
  }
  throw new Error('server timeout');
}

let srv;
try {
  await mkdir(capDir, { recursive: true });
  const adminEmail = process.env.CONTACT_E2E_ADMIN_EMAIL?.trim();
  const adminPassword = process.env.CONTACT_E2E_ADMIN_PASSWORD?.trim();

  if (!adminEmail || !adminPassword) {
    evidence.note =
      'CONTACT_E2E_ADMIN_EMAIL / CONTACT_E2E_ADMIN_PASSWORD not set — E15 BLOCKED (no auth bypass).';
    await writeFile(path.join(closureDir, 'ADMIN_QA_EVIDENCE.json'), JSON.stringify(evidence, null, 2));
    console.log(JSON.stringify({ E15: 'BLOCKED', reason: 'no admin credentials' }));
    process.exit(0);
  }

  if (process.env.CONTACT_E2E_NO_SPAWN !== '1') {
    srv = spawn('npm run start', {
      cwd: repoRoot,
      shell: true,
      stdio: 'pipe',
      env: { ...process.env, PORT: port },
    });
  }
  await waitServer();
  evidence.BUILD_ID = (await readFile(path.join(repoRoot, '.next', 'BUILD_ID'), 'utf8').catch(() => '')).trim();

  const marker = process.env.CONTACT_E2E_ADMIN_MARKER?.trim() || `[ADMIN-QA-${Date.now().toString(36)}]`;
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL?.trim();
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY?.trim();
  let seedConsultId = null;
  if (process.env.CONTACT_E2E_ALLOW_DB_WRITES === '1') {
    const seedRes = await fetch(`${base}/api/private/leads`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        type: 'private',
        name: `합성관리자QA ${marker}`,
        phone: `0105555${String(Date.now()).slice(-4)}`,
        content: `${marker} E15 admin inbox seed`,
        preferred_format: 'undecided',
        cta_intent_id: 'private_fit_consult',
        acquisition: { entrySurface: 'direct' },
      }),
    });
    const seedJson = await seedRes.json().catch(() => null);
    seedConsultId = seedJson?.leadId ?? null;
    evidence.seedConsultId = seedConsultId;
  }

  const browser = await chromium.launch();
  const page = await browser.newPage();

  await page.goto(`${base}/admin/consult`, { waitUntil: 'load' });
  evidence.checks.push({ step: 'unauth-admin', url: page.url() });

  await page.goto(`${base}/login?type=admin&next=${encodeURIComponent('/admin/consult')}`, { waitUntil: 'load' });
  await page.locator('input[type="email"], input[name="email"], input:not([type="password"])').first().fill(adminEmail);
  await page.locator('input[type="password"]').first().fill(adminPassword);
  await page.getByRole('button', { name: /로그인|login/i }).click();
  await page.waitForTimeout(2500);

  await page.goto(`${base}/admin/consult`, { waitUntil: 'load', timeout: 60000 });
  await page.waitForTimeout(2000);
  const bodyText = await page.evaluate(() => document.body.innerText);
  const foundSeed = seedConsultId ? bodyText.includes(seedConsultId.slice(0, 8)) || bodyText.includes('합성관리자QA') : false;

  await page.screenshot({ path: path.join(capDir, 'admin-inbox-authenticated.png'), fullPage: false });

  const apiRes = await page.request.get(`${base}/api/admin/consult?limit=30`);
  evidence.adminApiStatus = apiRes.status();
  const apiJson = await apiRes.json().catch(() => null);
  const inApiList =
    seedConsultId && Array.isArray(apiJson?.rows)
      ? apiJson.rows.some((r) => r.id === seedConsultId)
      : false;

  evidence.checks.push({ step: 'auth-admin-consult', url: page.url(), adminApiStatus: apiRes.status(), inApiList, foundSeed });

  await browser.close();

  if (seedConsultId && url && key && process.env.CONTACT_E2E_ALLOW_DB_WRITES === '1') {
    await createClient(url, key, { auth: { persistSession: false } })
      .from('consultations')
      .delete()
      .eq('id', seedConsultId);
  }

  const pass = apiRes.status() === 200 && inApiList;
  evidence.E15 = pass ? 'PASS' : 'FAIL';
  evidence.overall = pass ? 'PASS' : 'FAIL';
  await writeFile(path.join(closureDir, 'ADMIN_QA_EVIDENCE.json'), JSON.stringify(evidence, null, 2));
  console.log(JSON.stringify({ E15: evidence.E15, adminApiStatus: apiRes.status(), inApiList }, null, 2));
  if (!pass) process.exit(1);
} catch (e) {
  evidence.error = String(e.message ?? e);
  evidence.E15 = 'BLOCKED';
  await writeFile(path.join(closureDir, 'ADMIN_QA_EVIDENCE.json'), JSON.stringify(evidence, null, 2)).catch(() => {});
  console.error(e);
  process.exit(1);
} finally {
  if (srv) srv.kill('SIGTERM');
}
